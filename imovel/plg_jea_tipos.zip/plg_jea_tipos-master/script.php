<?php

/**
 *
 * @package		Joomla
 * @subpackage	JEA
 * @copyright	Copyright (C) 2011 PHILIP Sylvain. All rights reserved.
 * @license		GNU/GPL, see LICENSE.txt
 * Joomla Estate Agency is free software. This version may have been modified pursuant to the
 * GNU General Public License, and as distributed it includes or is derivative
 * of works licensed under the GNU General Public License or other free or open
 * source software licenses.
 *
 */
// No direct access to this file
defined('_JEXEC') or die('Restricted access');

jimport('joomla.filesystem.folder');
jimport('joomla.database.database');

/**
 * Install Script file of JEA component
 */
class plgjeatiposInstallerScript {

    /**
     * method to run before an install/update/uninstall method
     *
     * @return void
     */
    function preflight($type, $parent) {
        // Create a new field (tipos_lista) in the properties table

        $db = JFactory::getDbo();
        $db->setQuery('SHOW COLUMNS FROM #__jea_properties');
        $cols = $db->loadObjectList('Field');
        if (!isset($cols['tipos_lista'])) {
            $query = 'ALTER TABLE `#__jea_properties` '
                    . "ADD `tipos_lista` VARCHAR(255) NOT NULL DEFAULT ''";
            $db->setQuery($query);
            $db->query();
        }

        $db = JFactory::getDbo();
        var_dump($db);

        $verificaTabela = $db->getTableList();
        if (!in_array('#__jea_tipos', $verificaTabela)) {
            //$query=' CREATE TABLE #__jea_tipos; ';
          //  $db->getTableCreate('teste');
            echo 'tabela_criada';
            $prefix = $db->getPrefix();
            $tables = $prefix . 'jea_tipos';
            //$result = $db->getTableCreate($tables);
            //print_r($result);
            $query='CREATE TABLE '.$tables . 
                    "( 
                    tipos_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
                    tipos_nome VARCHAR(255) NOT NULL DEFAULT '',
                    tipos_descricao VARCHAR(255) NOT NULL DEFAULT ''
                    ) ENGINE=innodb";
            $db->setQuery($query);
          $db->query();
        }
        //var_dump($verificaTabela);
        //var_dump($query);
        /*
          $db->setQuery('SHOW COLUMNS FROM #__jea_tipos');
          $cols = $db->loadObjectList('Field');
          if (!isset($cols['tipos_id'])) {
          $query = 'ALTER TABLE `#__jea_tipos` '
          . " ADD `tipos_id` MEDIUMINT NOT NULL AUTO_INCREMENT "
          . " ADD `tipos_nome` VARCHAR(255) NOT NULL DEFAULT '' "
          . " ADD `tipos_nome` VARCHAR(255) NOT NULL DEFAULT '' ";
          $db->setQuery($query);
          $db->query();
          } 
         
         */
    }

}
